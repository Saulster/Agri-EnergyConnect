﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PROG7311P2.Models
{
    public class UserRoleModel
    {
        public int UserID { get; set; }
        public int UserRole { get; set; }
        public string RolePosition { get; set; }
    }
}