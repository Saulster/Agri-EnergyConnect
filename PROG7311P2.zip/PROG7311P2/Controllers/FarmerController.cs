﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using PROG7311P2.Models;

namespace PROG7311P2.Controllers
{
    public class FarmerController : Controller
    {
        private SqlConnection con_string = new SqlConnection(PROG7311P2.Properties.Resources.conString);

        [HttpGet]
        public ActionResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddProduct(ProductModel product)
        {
            if (ModelState.IsValid)
            {
                if (!string.IsNullOrEmpty(User.Identity.Name))
                {
                    if (int.TryParse(User.Identity.Name, out int userID))
                    {
                        product.UserID = userID;
                        // Proceed with adding the product
                        return RedirectToAction("ProductList"); // or any other appropriate action
                    }
                    else
                    {
                        // Handle invalid user ID format
                        ModelState.AddModelError("", "User ID is not in the correct format.");
                    }
                }
                else
                {
                    // Handle null or empty User.Identity.Name
                    View("ProductList"); // Redirect to login page or another appropriate action
                }
            }
            // If ModelState is not valid or other errors occur, return the view with the model
            return View(product);
        }


        /*public ActionResult AddProduct(ProductModel product)
        {
            if (ModelState.IsValid)
            {
                int userID = Convert.ToInt32(User.Identity.Name); // Assuming UserID is stored as the user's name

                product.UserID = userID;

                int result = product.Insert_Product_Data();

                if (result > 0)
                {
                    return RedirectToAction("ProductList");
                }
                else
                {
                    ModelState.AddModelError("", "An error occurred while adding the product.");
                }
            }
            return View(product);
        }*/

        [HttpGet]
        public ActionResult ProductList()
        {
            int userID = Convert.ToInt32(User.Identity.Name);
            var products = GetProductsByUserID(userID);
            return View(products);
        }

        private List<ProductModel> GetProductsByUserID(int userID)
        {
            List<ProductModel> products = new List<ProductModel>();

            try
            {
                using (con_string)
                {
                    con_string.Open();
                    string sql = "SELECT ProductID, productName, productCategory, productionDate FROM productTable WHERE userID = @UserID";
                    using (SqlCommand cmd = new SqlCommand(sql, con_string))
                    {
                        cmd.Parameters.AddWithValue("@UserID", userID);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ProductModel product = new ProductModel
                                {
                                    ProductID = reader.GetInt32(0),
                                    Name = reader.GetString(1),
                                    Category = reader.GetString(2),
                                    ProductionDate = reader.GetDateTime(3),
                                    UserID = userID
                                };
                                products.Add(product);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("An error occurred while fetching the products. Please try again later.");
            }

            return products;
        }
    }
}
