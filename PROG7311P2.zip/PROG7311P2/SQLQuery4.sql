﻿CREATE TRIGGER trg_LinkUserID
ON userTable
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @UserID INT;

    -- Get the newly inserted UserID
    SELECT @UserID = UserID FROM inserted;

    -- Update userRoleTable
    UPDATE userRoleTable
    SET UserID = @UserID
    WHERE UserID IS NULL;

    -- Update productTable
    UPDATE productTable
    SET UserID = @UserID
    WHERE UserID IS NULL;
END;
