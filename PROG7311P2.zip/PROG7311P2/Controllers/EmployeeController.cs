﻿using PROG7311P2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace PROG7311P2.Controllers
{
    public class EmployeeController : Controller
    {
        private static List<TestModel> users = new List<TestModel>();
        private static List<ProductModel> products = new List<ProductModel>();

        [HttpGet]
        public ActionResult AddFarmerProfile()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddFarmerProfile(TestModel user)
        {
            if (ModelState.IsValid)
            {
                users.Add(user);
                return RedirectToAction("ViewFarmerProfiles");
            }
            return View(user);
        }

        [HttpGet]
        public ActionResult ViewFarmerProfiles()
        {
            return View(users);
        }

        [HttpGet]
        public ActionResult ViewFarmerProducts(int userId)
        {
            var farmerProducts = products.Where(p => p.UserID == userId).ToList();
            return View(farmerProducts);
        }

        [HttpGet]
        public ActionResult SearchProducts(string productType, DateTime? startDate, DateTime? endDate)
        {
            var filteredProducts = products.AsQueryable();

            if (!string.IsNullOrEmpty(productType))
            {
                filteredProducts = filteredProducts.Where(p => p.Category == productType);
            }

            if (startDate.HasValue)
            {
                filteredProducts = filteredProducts.Where(p => p.ProductionDate >= startDate.Value);
            }

            if (endDate.HasValue)
            {
                filteredProducts = filteredProducts.Where(p => p.ProductionDate <= endDate.Value);
            }

            return View(filteredProducts.ToList());
        }
    }
}
