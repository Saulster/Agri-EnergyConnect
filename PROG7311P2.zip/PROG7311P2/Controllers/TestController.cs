﻿/*using PROG7311P2.Models;
using System.Web.Mvc;

namespace PROG7311P2.Controllers
{
    public class TestController : Controller
    {
        public TestModel test = new TestModel();

        [HttpGet]
        public ActionResult Test()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Test(TestModel user)
        {
            if (ModelState.IsValid)
            {
                var result = test.Insert_User(user);
                if (result > 0)
                {
                    // Handle successful registration
                    var userRole = new UserRoleModel
                    {
                        UserID = user.UserID,
                        UserRole = user.Role,
                    };
                    return RedirectToAction("Login");
                }
                ModelState.AddModelError("", "Error inserting user.");
            }
            return View(user);
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View("~/Views/Login/LoginView.cshtml");
            //return View("~/Views/Farmer/ProductList.cshtml");
        }

        [HttpPost]
        public ActionResult Login(Login login)
        {
            if (ModelState.IsValid)
            {
                var userId = test.Authenticate_User(login.Email, login.Password);
                if (userId > 0)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid email or password.");
                }
            }
            return View("~/Views/Farmer/ProductList.cshtml");
            //return View("~/Views/Login/LoginView.cshtml");

        }
    }
}
*/
using PROG7311P2.Models;
using System;
using System.Data.SqlClient;
using System.Web.Mvc;

namespace PROG7311P2.Controllers
{
    public class TestController : Controller
    {
        //private static string con_string = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=DATABASEFORPROG7311P2;AttachDbFilename=C:\USERS\LAB_SERVICES_STUDENT\SOURCE\REPOS\PROG7311P2\APP_DATA\DATABASEFORPROG7311P2.MDF;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        // private static string con_string = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=DatabaseForPROG7311P2;Integrated Security=True;Connect Timeout=30";

        //private static string con_string = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=test;Data Source=labVMH8OX\\SQLEXPRESS";
        public SqlConnection con_string = new SqlConnection(PROG7311P2.Properties.Resources.conString);
        private TestModel test = new TestModel();

        [HttpGet]
        public ActionResult Register()
        {
            return View("~/Views/Home/RegisterView.cshtml");
        }

        [HttpPost]
        public ActionResult Register(TestModel user)
        {
            if (ModelState.IsValid)
            {
                var result = test.Insert_User(user);
                if (result > 0)
                {
                    var userRole = new UserRoleModel
                    {
                        UserID = user.UserID,
                        UserRole = user.Role
                    };
                    return RedirectToAction("Login");
                }
                ModelState.AddModelError("", "Error inserting user.");
            }
            return View(user);
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View("~/Views/Login/LoginView.cshtml");
        }

        [HttpPost]
        public ActionResult Login(Login login)
        {
            var userId = test.Authenticate_User(login.Email, login.Password);
            if (userId > 0)
            {
                var userRole = GetUserRole(userId);
                if (userRole == 1) // 1 is the role for Farmer
                {
                    return View("~/Views/Farmer/ProductList.cshtml");
                }
                else if (userRole == 2) // 2 is the role for Employee
                {
                    return View("~/Views/Employee/ViewFarmerProductsView.cshtml");
                }
                return View("~/Views/Home/Index.cshtml");
            }
            else 
            {
                ModelState.AddModelError("", "Invalid email or password.");
                return View("~/Views/Login/LoginView.cshtml");
            }
        }

        private int GetUserRole(int userId)
        {
            using (con_string)
            {
                string sql = "SELECT userRole FROM userTable WHERE userId = @UserId";
                using (SqlCommand cmd = new SqlCommand(sql, con_string))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    con_string.Open();
                    var result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        return Convert.ToInt32(result);
                    }
                }
            }
            return 1; // Default farmer
        }
    }
}
