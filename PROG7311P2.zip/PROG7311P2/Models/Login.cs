﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PROG7311P2.Models
{
    public class Login
    {

        public string Email { get; set; }
        public string Password { get; set; }
    }
}