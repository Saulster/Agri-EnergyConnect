﻿CREATE TRIGGER trg_UpdateUserRole
ON userTable
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @UserID INT;
    DECLARE @NewUserRole INT;

    -- Get the updated values
    SELECT @UserID = UserID, @NewUserRole = userRole FROM inserted;

    -- Update userRoleTable
    UPDATE userRoleTable
    SET userRole = @NewUserRole,
        userRolePosition = CASE @NewUserRole
                              WHEN 1 THEN 'Farmer'
                              WHEN 2 THEN 'Employee'
                              ELSE userRolePosition -- Keep the current value if not 1 or 2
                          END
    WHERE UserID = @UserID;
END;
