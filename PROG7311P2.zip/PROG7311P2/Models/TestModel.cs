﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace PROG7311P2.Models
{
    public class TestModel
    {
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Surname is required")]
        public string Surname { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Role is required")]
        public int Role { get; set; }

        public int UserID { get; set; }

        // private static string con_string = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=test;Data Source=labVMH8OX\\SQLEXPRESS";
       // private static string con_string = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=DatabaseForPROG7311P2;Integrated Security=True;Connect Timeout=30";
        public SqlConnection con_string = new SqlConnection(PROG7311P2.Properties.Resources.conString);
        public int Insert_User(TestModel t)
        {
            int rowsaffected = 0;
            try
            {
                if (string.IsNullOrEmpty(t.Name) || string.IsNullOrEmpty(t.Surname) || string.IsNullOrEmpty(t.Email) || string.IsNullOrEmpty(t.Password) || t.Role == 0)
                {
                    throw new Exception("Please fill in all required fields.");
                }
                using ((con_string))
                {
                    con_string.Open();
                    string sql = "INSERT INTO userTable (userName, userSurname, userEmail, userPassword, userRole) VALUES (@Name, @Surname, @Email, @Password, @Role)";
                    using (SqlCommand cmd = new SqlCommand(sql, con_string))
                    {
                        cmd.Parameters.AddWithValue("@Name", t.Name);
                        cmd.Parameters.AddWithValue("@Surname", t.Surname);
                        cmd.Parameters.AddWithValue("@Email", t.Email);
                        cmd.Parameters.AddWithValue("@Password", t.Password);
                        cmd.Parameters.AddWithValue("@Role", t.Role);

                        rowsaffected = cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) // User already exists
                {
                    throw new Exception("User already exists. Please choose a different email address.");
                }
                else
                {

                    throw new Exception("An error occurred while registering the user. Please try again later.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return rowsaffected;
        }

        public int Authenticate_User(string email, string password)
        {
            int userId = 0;
            try
            {
                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                {
                    throw new Exception("Please enter both email and password.");
                }

                using (con_string)
                {
                    string sql = "SELECT userId FROM userTable WHERE userEmail = @Email AND userPassword = @Password";
                    using (SqlCommand cmd = new SqlCommand(sql, con_string))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", password);

                        con_string.Open();
                        var result = cmd.ExecuteScalar();
                        if (result != null)
                        {
                            userId = Convert.ToInt32(result);
                        }
                    }
                }
            }
            catch (SqlException ex)
            {

                throw new Exception("An error occurred while authenticating the user. Please try again later.");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return userId;
        }
    }
}
