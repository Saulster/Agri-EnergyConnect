﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PROG7311P2.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Creating a digital ecosystem where farmers, green energy experts, and enthusiasts can delve into the realms of sustainable agriculture and renewable energy.";

            return View();
        }

        public ActionResult Contact()
        {
            if (User.Identity.IsAuthenticated)
            {
                string userName = User.Identity.Name;

                ViewBag.UserName = userName;
            }
            else
            {
                ViewBag.Message = "Login to view your profile.";
            }

            return View();
        }
    }
}
