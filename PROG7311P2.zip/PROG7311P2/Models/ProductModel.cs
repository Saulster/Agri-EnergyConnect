﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace PROG7311P2.Models
{
    public class ProductModel
    {
        [Key]
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Product Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Category is required")]
        public string Category { get; set; }

        [Required(ErrorMessage = "Production Date is required")]
        [DataType(DataType.Date)]
        public DateTime ProductionDate { get; set; }

        public int UserID { get; set; }

        private SqlConnection con_string = new SqlConnection(PROG7311P2.Properties.Resources.conString);

        public int Insert_Product_Data()
        {
            int rowsaffected = 0;
            try
            {
                if (string.IsNullOrEmpty(Name) || string.IsNullOrEmpty(Category) || ProductionDate == DateTime.MinValue || UserID == 0)
                {
                    throw new Exception("Please fill in all required fields.");
                }

                using (con_string)
                {
                    con_string.Open();
                    string sql = "INSERT INTO productTable (productName, productCategory, productionDate, userID) VALUES (@Name, @Category, @ProductionDate, @UserID)";
                    using (SqlCommand cmd = new SqlCommand(sql, con_string))
                    {
                        cmd.Parameters.AddWithValue("@Name", Name);
                        cmd.Parameters.AddWithValue("@Category", Category);
                        cmd.Parameters.AddWithValue("@ProductionDate", ProductionDate);
                        cmd.Parameters.AddWithValue("@UserID", UserID);

                        rowsaffected = cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("An error occurred while inserting the product. Please try again later.");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return rowsaffected;
        }
    }
}
